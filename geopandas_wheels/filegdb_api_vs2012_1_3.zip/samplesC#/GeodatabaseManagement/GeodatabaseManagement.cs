﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Esri.FileGDB;

namespace GeodatabaseManagement
{
  class GeodatabaseManagement
  {
    static void Main(string[] args)
    {
      try
      {
        Geodatabase geodatabase = Geodatabase.Create("../GeodatabaseManagement/GdbManagement.gdb");
        Console.WriteLine("The geodatabase has been created.");

        geodatabase.Close();

        geodatabase = Geodatabase.Open("../GeodatabaseManagement/GdbManagement.gdb");
        Console.WriteLine("The geodatabase has been opened.");

        geodatabase.Close();

        Geodatabase.Delete("../GeodatabaseManagement/GdbManagement.gdb");
        Console.WriteLine("The geodatabase has been deleted.");

      }
      catch (FileGDBException ex)
      {
        Console.WriteLine("{0} - {1}", ex.Message, ex.ErrorCode);
      }
      catch (Exception ex)
      {
        Console.WriteLine("General exception.  " + ex.Message);
      }
    }
  }
}
